#include <iostream>
#include <time.h>
using namespace std;

int main()
{
    int time_taken;
    struct timespec start,end;
    
    timespec_get(&start, TIME_UTC);
    
    int n;
    cout<<"Pick a number from this set: 32, 64, 128, 256, 512";
    cin>>n;
    //cout<<"n is "<<n;
    double m1[n][n];
    double m2[n][n];
    double mul[n][n];
    
    for( int i=0; i<n; i++)
    {
      for( int j=0; j<n; j++)
      {
        m1[i][j]=rand();
        m2[i][j]=rand();
        mul[i][j]=0;
      }
    }
    
    for(int k = 0; k<n; k++)
     {
        for(int j = 0; j<n; j++)
        {
            for(int i = 0; i<n; i++)
            {
                mul[i][j] += (m1[i][k]) * (m2[k][j]);
            }
        }  
     }
     
    timespec_get(&end, TIME_UTC);
    time_taken = (end.tv_sec - start.tv_sec) * 1e9;
    time_taken = (time_taken + (end.tv_nsec - start.tv_nsec)) * 1e-9;
  
    cout<<"Time taken is:"<<time_taken;
     
     return 0;
}