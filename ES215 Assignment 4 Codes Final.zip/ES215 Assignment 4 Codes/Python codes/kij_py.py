import random
import timeit

start = timeit.default_timer()
print("Pick a number from: 32, 64, 128, 256, 512")
n = int(input())

m1 = []
m2 = []
mul = []

for i in range(n):
    row = []
    for j in range(n):
        row.append(random.uniform(-2147483648, 2147483647))
    m1.append(row)

for i in range(n):
    row = []
    for j in range(n):
        row.append(random.uniform(-2147483648, 2147483647))
    m2.append(row)

for k in range(n):
    row = []
    for i in range(n):
        value = 0
        for j in range(n):
            value += m1[i][k] * m2[k][j]

        row.append(value)
    mul.append(row)
stop = timeit.default_timer()
print("Time : ", stop-start)