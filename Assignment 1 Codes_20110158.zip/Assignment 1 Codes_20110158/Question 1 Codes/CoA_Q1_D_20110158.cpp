#include <iostream>

using namespace std;

int main()
{
    int n=100;
    int fib_numbers[n];
    
    int first_fib=0;
    int second_fib=1;
    int next_fib;
    
    for( int i=0; i<n; i++)
    {
      fib_numbers[i]=-2;
    }
    
    for( int j=0; j<n; j++)
    {
      if(j<=1)
      {
        next_fib=j;
      }
      else
      {
        if(fib_numbers[j]!=-2)
        {
          next_fib=fib_numbers[j];
        }
        else
        {
            next_fib=first_fib+second_fib;
            first_fib=second_fib;
            second_fib=next_fib;
            fib_numbers[j]=next_fib;
        }
      }
      
      cout<<next_fib<<endl;
      
    }

    return 0;
}
//Author-Rahul Chembakasseril